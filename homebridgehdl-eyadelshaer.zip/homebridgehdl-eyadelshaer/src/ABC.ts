export abstract class ABCDevice {}

export abstract class ABCListener {}